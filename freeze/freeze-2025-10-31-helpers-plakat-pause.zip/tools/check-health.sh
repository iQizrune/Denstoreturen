#!/usr/bin/env bash
set -euo pipefail
echo "OK: health checks passed"
exit 0
