#!/usr/bin/env node
const os = require('os');
function line(s=''){process.stdout.write(String(s)+os.EOL);}
line('[report:imports] start');
line('status: ok (stub)');
line('details: denne rapporten er en plassholder og kan utvides senere.');
line('[report:imports] end');
