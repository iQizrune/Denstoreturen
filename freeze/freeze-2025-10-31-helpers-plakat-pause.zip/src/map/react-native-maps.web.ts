import React from 'react';
export default function MapView(): any { return React.createElement('div', { style: { display: 'none' } }); }
export function Marker(): any { return null as any; }
export function Polyline(): any { return null as any; }
export const PROVIDER_DEFAULT: any = 'default';
