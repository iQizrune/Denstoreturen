// src/types/helpStatus.ts
// Status for et hjelpemiddel i sekken
export type HelpStatus = "unused" | "won" | "lost";
