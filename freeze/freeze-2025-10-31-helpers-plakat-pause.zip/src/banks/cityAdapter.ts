// Minimal, synkron stub som matcher StopPanel-forventningene:
// - to argumenter (cityId, age)
// - returnerer en liste (QA[]) — vi bruker any[] for å være kompatibel.
export function loadCityBank(cityId: string, age?: any): any[] {
  // TODO: Bytt til ekte by-spørsmål senere
  return [];
}
