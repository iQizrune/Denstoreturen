// CLEAN AUTO-GENERATED from Avdekking.zip (macOS resource forks removed)
export const REVEAL_ASSETS: Record<string, any> = {
  "albert-einstein": require("@/assets/Avdekking/albert-einstein.jpg"),
  "audrey-hepburn": require("@/assets/Avdekking/audrey-hepburn.jpg"),
  "elizabeth-taylor": require("@/assets/Avdekking/elizabeth-taylor.jpg"),
  "elvis": require("@/assets/Avdekking/elvis.png"),
  "frihetsgudinnen": require("@/assets/Avdekking/frihetsgudinnen.jpg"),
  "ghandi": require("@/assets/Avdekking/ghandi.png"),
  "muhammed-ali": require("@/assets/Avdekking/muhammed-ali.png"),
  "nelson-mandela": require("@/assets/Avdekking/nelson-mandela.png"),
  "spiderman": require("@/assets/Avdekking/spiderman.jpg"),
  "taj-mahal": require("@/assets/Avdekking/taj-mahal.jpg"),
  "winston-churchhill": require("@/assets/Avdekking/winston-churchhill.png"),
};

