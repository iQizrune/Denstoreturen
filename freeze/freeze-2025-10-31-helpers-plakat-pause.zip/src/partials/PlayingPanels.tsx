// src/partials/PlayingPanels.tsx
export { default } from "./PlayingPanels_pauseable";
