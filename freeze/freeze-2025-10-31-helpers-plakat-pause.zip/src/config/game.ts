export const POINTS_PER_CORRECT = 10;
