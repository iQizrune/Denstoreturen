
// src/features/mine-ting/FooterBtn.ts
// Delt type for footer-knapper (hvis andre komponenter vil bruke den).
export type FooterBtn = { label: string; onPress: () => void; variant?: "primary" | "ghost" };
