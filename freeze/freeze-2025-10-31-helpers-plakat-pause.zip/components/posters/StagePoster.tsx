import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";

type Props = {
  visible: boolean;
  fromName: string;
  toName: string;
  meters: number;
    etappeNo?: number;
  onStart: () => void; // "Sett i gang"
  onClose?: () => void; // hvis du vil kunne lukke uten å starte
};

export default function StagePoster({ visible, fromName, toName, meters, etappeNo, onStart, onClose }: Props) {
  if (!visible) return null;
  return (
    <View style={styles.wrap} pointerEvents="auto">
      <View style={styles.card}>
        <Text style={styles.heading}>{etappeNo ? `Etappe ${etappeNo}` : "Neste etappe"}</Text>
        <Text style={styles.route}>{fromName} → {toName}</Text>
        <Text style={styles.distance}>{meters.toLocaleString('no-NO')} m</Text>

        <Pressable onPress={onStart} android_ripple={{ color: "#334155" }} style={styles.cta}>
          <Text style={styles.ctaText}>Sett i gang</Text>
        </Pressable>

        {onClose ? (
          <Pressable onPress={onClose} android_ripple={{ color: "#334155" }} style={styles.secondary}>
            <Text style={styles.secondaryText}>Senere</Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: "absolute",
    left: 0, right: 0, top: 0, bottom: 0,
    backgroundColor: "rgba(0,0,0,0.86)",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
  },
  card: {
    width: "92%",
    maxWidth: 480,
    backgroundColor: "#111827",
    borderColor: "#374151",
    borderWidth: 1,
    borderRadius: 20,
    paddingVertical: 22,
    paddingHorizontal: 18,
    alignItems: "center",
  },
  heading: { color: "#9ca3af", fontWeight: "800", marginBottom: 6 },
  route: { color: "white", fontSize: 22, fontWeight: "900", textAlign: "center" },
  distance: { color: "#cbd5e1", fontSize: 16, fontWeight: "700", marginTop: 6, marginBottom: 14 },
  cta: { backgroundColor: "#60a5fa", borderRadius: 12, paddingVertical: 12, paddingHorizontal: 20, minWidth: 200, alignItems: "center" },
  ctaText: { color: "#0b1220", fontWeight: "800", fontSize: 16 },
  secondary: { marginTop: 10, backgroundColor: "#1f2937", borderRadius: 10, paddingVertical: 10, paddingHorizontal: 16, borderWidth: 1, borderColor: "#374151" },
  secondaryText: { color: "white", fontWeight: "700" },
});
