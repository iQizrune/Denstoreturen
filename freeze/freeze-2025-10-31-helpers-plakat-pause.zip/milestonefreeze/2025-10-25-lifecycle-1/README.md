# Milestone Freeze

Denne mappen beskriver en frossen tilstand av repoet. Se TAG.txt, BRANCH.txt og COMMIT.txt for referanser. Kjør skriptene i scripts/-mappen for å fryse eller gjenopprette.
