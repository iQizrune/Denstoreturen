/// <reference types="jest" />
declare function require(path: string): any;
