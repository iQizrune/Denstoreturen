import React from "react";
import { View, Text } from "react-native";

export default function DevHub() {
  return (
    <View style={{ padding: 16 }}>
      <Text>DevHub (stub)</Text>
    </View>
  );
}
