import React from "react";
import { View, Text } from "react-native";
export default function HomePhasePanel() {
  return <View style={{ padding: 16 }}><Text>HomePhasePanel (stub)</Text></View>;
}
