Dette er midlertidig arkiv for ubrukte filer per 2025-10-23.
Flytt tilbake ved behov.
