declare function require(path: string): any;
