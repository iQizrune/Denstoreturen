/* iQiz – enkel og robust ruttetegning + ikoner (ingen venting, bare tegn) */

function normLatLng(p) {
  if (!p) return null;
  if (Array.isArray(p) && p.length >= 2) {
    const a = Number(p[0]), b = Number(p[1]);
    const looksLonLat = Math.abs(a) > 90 && Math.abs(b) <= 90;
    return looksLonLat ? [b, a] : [a, b];
  }
  if (typeof p === "object") {
    const lat = p.lat ?? p.latitude;
    const lng = p.lng ?? p.lon ?? p.longitude;
    if (lat != null && lng != null) return [Number(lat), Number(lng)];
  }
  return null;
}

document.addEventListener("DOMContentLoaded", () => {
  if (!window.NODES || !window.ROUTE_ORDER || !window.ROUTE_LEGS) {
    console.error("DATA MISSING: NODES/ORDER/LEGS mangler.");
    return;
  }

  const NODES = window.NODES;
  const ORDER = window.ROUTE_ORDER;
  const LEGS  = window.ROUTE_LEGS;

  const map = L.map("map", { preferCanvas: true });
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18,
    attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
  }).addTo(map);

  const coord = (id) => {
    const n = NODES[id];
    return n ? [Number(n.lat), Number(n.lng)] : null;
  };

  const markers = L.layerGroup().addTo(map);
  ORDER.forEach((id, idx) => {
    const c = coord(id);
    if (!c) return;
    L.marker(c, { title: NODES[id]?.name || id })
      .addTo(markers)
      .bindPopup(`${idx + 1}. ${NODES[id]?.name || id}`);
  });

  const legsLayer = L.layerGroup().addTo(map);
  const fitPts = [];
  let total = 0, drawn = 0;

  LEGS.forEach((leg) => {
    const a = coord(leg.from);
    const b = coord(leg.to);
    if (!a || !b) return;

    total += Number(leg.distanceMeters || 0);

    let pts = null;
    if (Array.isArray(leg.path) && leg.path.length >= 2) {
      const normed = leg.path.map(normLatLng).filter(Boolean);
      if (normed.length >= 2) pts = normed;
    }
    if (!pts) pts = [a, b];

    const poly = L.polyline(pts, {
  weight: 5,
  opacity: 0.95,
  color: "#ff3b3b",
  lineJoin: "round",
  lineCap: "round",
}).addTo(legsLayer);

// Klikk på rutesegment ⇒ vis fra–til + km
poly.on("click", (e) => {
  const mid = pts[Math.floor(pts.length / 2)];
  const where = e.latlng || mid;
  const km = (Number(leg.distanceMeters || 0) / 1000).toFixed(1);
  const fromName = (NODES[leg.from]?.name || leg.from);
  const toName   = (NODES[leg.to]?.name || leg.to);
  L.popup()
    .setLatLng(where)
    .setContent(`<b>${fromName}</b> → <b>${toName}</b><br>${km} km`)
    .openOn(map);
});

    drawn++;
  });

  if (fitPts.length) map.fitBounds(fitPts, { padding: [30, 30] });
  else map.setView([64.5, 12], 4);

  const ec = document.getElementById("hud-count");
  const elg = document.getElementById("hud-legs");
  const et = document.getElementById("hud-total");
  const er = document.getElementById("hud-range");
  const fmtKm = (m) => (Number(m || 0) / 1000).toFixed(1) + " km";
  const name = (id) => (NODES[id]?.name || id || "–");

  if (ec) ec.textContent = Object.keys(NODES).length;
  if (elg) elg.textContent = LEGS.length;
  if (et) et.textContent = fmtKm(total);
  if (er && ORDER.length >= 2) er.textContent = `${name(ORDER[0])} → ${name(ORDER[ORDER.length - 1])}`;

  // --- IKONER (fra vår JSON eller GeoJSON hvis JSON mangler)
  (async () => {
    const iconLayer = L.layerGroup().addTo(map);

    async function j(url) {
      try { const r = await fetch(url); if (!r.ok) return null; return await r.json(); }
      catch { return null; }
    }

    const points = await j("./icon_placements_v2.json");
    if (points && Array.isArray(points)) {
      points.forEach((p) => {
        const icon = L.icon({
          iconUrl: p.icon_src,
          iconSize: [32, 32],
          iconAnchor: [16, 16],
          popupAnchor: [0, -14],
        });
        L.marker([p.placed_lat, p.placed_lng], { icon })
          .addTo(iconLayer)
          .bindPopup(`${p.stop_name || p.stop_id}`);
      });
      return;
    }

    const gj = await j("./icon_placements_relaxed.geojson");
    if (gj && gj.type === "FeatureCollection") {
      L.geoJSON(gj, {
        pointToLayer: (feat, latlng) => {
          const pr = feat.properties || {};
          const guessed =
            pr.index && (pr.id || pr.stop_id)
              ? `./iqiz-icons/${String(pr.index).padStart(2, "0")}-${pr.id || pr.stop_id}.svg`
              : "./iqiz-icons/01-lindesnes-fyr.svg";
          const icon = L.icon({
            iconUrl: pr.icon_src || guessed,
            iconSize: [32, 32],
            iconAnchor: [16, 16],
            popupAnchor: [0, -14],
          });
          return L.marker(latlng, { icon }).bindPopup(
            `${pr.name || pr.stop_name || pr.id || pr.stop_id || "Ikon"}`
          );
        },
      }).addTo(iconLayer);
    }
  })();
});
