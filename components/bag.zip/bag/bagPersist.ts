// bagPersist.ts
/**
 * Utenpåliggende persist-lag for "Mine ting" (bagStore).
 * Bruker KUN det offentlige API-et til bagStore for å hydrere og lagre,
 * så vi slipper å endre bagStore.ts nå.
 */

// Justér importstier etter hvor du la lagringsfilene:
import { bagStorageAsync } from "../../src/storage/adapters/bagStorage.async"; // <-- tilpass sti
import type { BagSnapshotV1 } from "../../src/storage/bagStorage";            // <-- tilpass sti

// bagStore ligger i samme mappe hos deg: components/bag/bagStore.ts
import * as bag from "./bagStore";

const STORAGE_VERSION = 1 as const;
const DEFAULT_PROFILE_ID = "single"; // TODO: bytt til ekte profileId når den er tilgjengelig

const storageKeyFor = (profileId: string) =>
  `@app/bag:v${STORAGE_VERSION}:${profileId}`;

export async function installBagPersistence(profileId: string = DEFAULT_PROFILE_ID): Promise<void> {
  const key = storageKeyFor(profileId);

  // 1) HYDRER fra lagring
  try {
    const snap = await bagStorageAsync.load(key);
    if (snap) {
      const current = bag.getItems();

      // dedupe coats
      const haveCoats = new Set(current.coats ?? []);
      for (const c of snap.coats ?? []) {
        if (!haveCoats.has(c)) bag.addCoat(c);
      }

      // dedupe helps
      const haveHelps = new Set(current.helps ?? []);
      for (const h of snap.helps ?? []) {
        if (!haveHelps.has(h)) bag.addHelp(h);
      }

      // usedHelps (valgfritt): håndter her senere hvis du visualiserer “gull” basert på bruk
    }
  } catch {
    // Best effort: ikke la persisteringen knekke appen
  }

  // 2) LAGRE ved endring (lett debounce)
  let saveTimer: ReturnType<typeof setTimeout> | null = null;
  const debouncedSave = () => {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      const items = bag.getItems();
      const snapshot: BagSnapshotV1 = {
        version: 1,
        coats: Array.isArray(items.coats) ? items.coats.slice() : [],
        helps: Array.isArray(items.helps) ? items.helps.slice() : [],
        // usedHelps: items.usedHelps ? items.usedHelps.slice() : undefined,
      };
      try {
        await bagStorageAsync.save(key, snapshot);
      } catch {
        // swallow
      }
    }, 120);
  };

  // lagre én gang etter mulig init-endring
  debouncedSave();

  // abonner på endringer i bagStore
  bag.subscribe(() => {
    debouncedSave();
  });
}

/**
 * Tøm lagret sekk for en profil (for “Start helt på nytt”).
 * NB: Husk også å tømme runtime-state i bagStore (egen helper eller manuell opprydding).
 */
export async function clearBagForProfile(profileId: string = DEFAULT_PROFILE_ID): Promise<void> {
  const key = storageKeyFor(profileId);
  try {
    await bagStorageAsync.clear(key);
  } catch {
    // swallow
  }
}
