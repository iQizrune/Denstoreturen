// bagStorage.ts
export type BagSnapshotV1 = {
  version: 1;
  coats: string[];      // f.eks. ["mandal","grimstad"]
  helps: string[];      // id/slug for hjelpemidler
  usedHelps?: string[]; // valgfritt: markere korrekt brukt hjelpemiddel
};

export interface BagStorage {
  load(key: string): Promise<BagSnapshotV1 | null>;
  save(key: string, snapshot: BagSnapshotV1): Promise<void>;
  clear(key: string): Promise<void>;
}
